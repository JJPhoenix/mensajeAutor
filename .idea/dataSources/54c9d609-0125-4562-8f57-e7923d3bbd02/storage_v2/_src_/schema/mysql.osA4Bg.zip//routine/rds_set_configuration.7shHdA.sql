create
    definer = rdsadmin@localhost procedure rds_set_configuration(IN name varchar(30), IN value int)
sp: BEGIN
  DECLARE v_exists INT;
  DECLARE sql_logging BOOLEAN;

  
  
  
  
  
  SELECT COUNT(1) INTO v_exists FROM mysql.rds_configuration WHERE mysql.rds_configuration.name = name;
  IF v_exists = 0 THEN
    SET @err = CONCAT('Cannot set unknown configuration parameter ', QUOTE(name), ' using mysql.rds_set_configuration.');
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @err;  
  END IF;

  IF name = 'binlog retention hours' AND value NOT BETWEEN 1 AND 168 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'For binlog retention hours the value must be between 1 and 168 inclusive or be NULL';
  ELSEIF name = 'target delay' AND value NOT BETWEEN 0 AND 86400 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'For target delay the value must be between 0 and 86400 inclusive';
  ELSEIF name = 'source delay' THEN
    CALL mysql.rds_set_source_delay(value);
    LEAVE sp;
  END IF;

  SELECT @@sql_log_bin INTO sql_logging;

  
  BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
    SET @@sql_log_bin=OFF;

    UPDATE mysql.rds_configuration
    SET mysql.rds_configuration.value = value
    WHERE mysql.rds_configuration.name = name;
    commit;

    SET @@sql_log_bin=sql_logging;
  END;
END;

