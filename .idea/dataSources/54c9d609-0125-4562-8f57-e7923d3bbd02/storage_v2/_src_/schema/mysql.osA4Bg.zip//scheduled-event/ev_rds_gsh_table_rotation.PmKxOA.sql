create definer = rdsadmin@localhost event ev_rds_gsh_table_rotation on schedule
    every '7' DAY
        starts '2023-04-30 12:25:02'
    on completion preserve
    disable
    do
    CALL rds_rotate_global_status_history();

