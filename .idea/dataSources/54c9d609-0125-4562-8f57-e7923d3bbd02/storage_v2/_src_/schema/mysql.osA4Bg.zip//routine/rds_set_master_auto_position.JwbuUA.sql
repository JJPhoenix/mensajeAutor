create
    definer = rdsadmin@localhost procedure rds_set_master_auto_position(IN auto_position_mode tinyint(1))
BEGIN
  DECLARE v_service_state ENUM('ON', 'OFF', 'BROKEN');
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE sql_logging BOOLEAN;
  SELECT @@sql_log_bin, user(), version() INTO sql_logging, v_called_by_user, v_mysql_version;

  

  
  BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
    SET @@sql_log_bin=OFF;

    
    SET @cmd = CONCAT('CHANGE MASTER TO MASTER_AUTO_POSITION = ', auto_position_mode);
    STOP SLAVE;
    PREPARE rds_set_master FROM @cmd;
    EXECUTE rds_set_master;
    DEALLOCATE PREPARE rds_set_master;
    START SLAVE;
    SELECT CONCAT('Master Auto Position has been set to ', auto_position_mode,'.') AS Message;
    SELECT sleep(2);

    SELECT mysql.rds_replication_service_state() INTO v_service_state;
    IF v_service_state = 'ON' THEN
      SELECT 'Slave is running normally' AS Message;
      INSERT into mysql.rds_history(called_by_user, action, mysql_version, auto_position) values (v_called_by_user,'set_master_AP:OK', v_mysql_version, auto_position_mode);
      commit;
    ELSE
      INSERT into mysql.rds_history(called_by_user, action, mysql_version, auto_position) values (v_called_by_user,'set_master_AP:ERR', v_mysql_version, auto_position_mode);
      commit;
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Slave has encountered a new error. Please use SHOW SLAVE STATUS to see the error.';
    END IF;

    SET @@sql_log_bin=sql_logging;
  END;
END;

